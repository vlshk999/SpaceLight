﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMove : MonoBehaviour
{
    public int life = 3;
    public Transform keyFollowPoint;
    public float movementSpeed = 8; //rychlost pohybu
    public float jumpSpeed = 10; //rychlost (výška) skoku
    public float distanceToGround = 1; //vzádlenost hráče od země pro "paprsek"
    private BoxCollider2D boxCollider2d;

    Rigidbody2D rb;

    BoxCollider2D bc;
    int groundMask; //proměnná pro vrstvu země

    Animator animator;
    int speedHash = Animator.StringToHash("Speed");
    int jumpHash = Animator.StringToHash("Jump");
    bool isTurned = false;
    // Start is called before the first frame update
    void Start() 
    {
        rb = transform.parent.GetComponent<Rigidbody2D>(); //přivolání komponenty RigidBody2D do proměnné
        bc = GetComponent<BoxCollider2D>(); //přivolání komponenty podtřídy 
       
                                                    //Player BoxCollider2D do proměnné
        groundMask = LayerMask.GetMask("Ground");
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal"); //chození do stran (automaticky bere A a D)
    
        if(horizontalInput < 0 && !isTurned)
        {
            transform.localScale = new Vector2(-1, 1);
            isTurned = true;
        }
        else if(horizontalInput > 0 && isTurned)
        {
            transform.localScale = new Vector2(1, 1);
            isTurned = false;
        }
       
        animator.SetFloat(speedHash, Mathf.Abs(horizontalInput));

        Vector2 vel = rb.velocity;

        //rb.AddForce(transform.right * movementSpeed * horizontalInput);
        vel.x = (transform.right * movementSpeed * horizontalInput).x;

        if (Input.GetKeyDown(KeyCode.Space) && IsGrounded()) //skok
        {
            //rb.AddForce(transform.up * jumpSpeed);
            vel.y = (transform.up * jumpSpeed).y;
            animator.SetTrigger(jumpHash);
        }

        rb.velocity = vel;
    
    }

private bool IsGrounded() //zamezí hráči nekonečný skok
    {
    Vector2 rayStartPosition = transform.position;
    rayStartPosition.y -= (bc.bounds.size.y / 2); //získali jsme výšku bc a vzali jen spodek
    //paprsek níže
    Debug.DrawRay(rayStartPosition, Vector2.down * distanceToGround, Color.red, 1 ); //vykreslení paprsku
   
    RaycastHit2D hit = Physics2D.Raycast(rayStartPosition, Vector2.down, distanceToGround,groundMask);
    
    if(hit)
    {
        Debug.Log("Hit" + hit.collider.name);
    return true;
    }
    return false;
  }

void  OnCollisionEnter2D (Collision2D col)
    {
        if(col.gameObject.tag.Equals ("Enemy"))
        {
            SceneManager.LoadScene ("SampleScene");
            life =- 1;
        }
    }
}
